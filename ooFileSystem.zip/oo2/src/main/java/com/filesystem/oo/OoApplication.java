package com.filesystem.oo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OoApplication {

	public static void main(String[] args) {
		SpringApplication.run(OoApplication.class, args);
	}

}
