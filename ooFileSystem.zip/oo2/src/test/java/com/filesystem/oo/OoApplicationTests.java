package com.filesystem.oo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OoApplicationTests {

	@Test
	void contextLoads() {
	}

}
